import java.util.ArrayList;
/**
*This is a FastFoodKitchen class to manage BurgerOrder objects.
*@author Luis 
*@version 1.0
*/
public class FastFoodKitchen{
       //FIELDS
    private ArrayList<BurgerOrder> orderList = new ArrayList<BurgerOrder>(); //arrayList of BurgerOrder objects called 'orderList'.
    private static int nextOrderNum=1; //used to keep track of orderNumber for the class itself. THE ORDER ID.

/**
* Constructs a FastFoodKitchen object with 3 inital BurgerOrder objects. 
* After creating each BurgerObject it's added to the orderList ArrayList.
* and incrementing the nextOrderNum field.
*
*/
   //OVERLOADED CONSTRUCTOR// to make FastFoodKitchen objects.
    public FastFoodKitchen(){
        BurgerOrder order1 = new BurgerOrder(3,5,4,10,false,getNextOrderNum());
        orderList.add(order1);
        incrementNextOrderNum();

        BurgerOrder order2 = new BurgerOrder(0,0,3,3,true,getNextOrderNum());
        orderList.add(order2);
        incrementNextOrderNum();

        BurgerOrder order3 = new BurgerOrder(1,1,0,2,false,getNextOrderNum());
        orderList.add(order3);
        incrementNextOrderNum();
    }
//METHODS//
/**
* Method to get the nextOrderNum of the FastFoodKitchen class.
*
*@return the order num.
*
*/
//GET NEXT ORDER NUM// returns the nextOrderNumber of the class FastFoodKitchen.
private static int getNextOrderNum(){
    return nextOrderNum;
    }

/**
* Method to increment the nextNumOrder by 1.
*
*@return the order number incremented by 1.
*
*/
//INCREMENT NEXT ORDER NUM// increments by 1, the nextOrderNumber of the class FastFoodKitchen.
private static void incrementNextOrderNum(){
    nextOrderNum +=1;
    }

/**
* Method to add another BurgerOrder object to orderList ArrayList. 
* Will also increment the nextOrderNum.
*
*@param ham     determines how many hamburgers is initilized to order.
*@param cheese  determines how many cheeseburgers is initilized to order.
*@param veggie  determines how many veggieburgers is initilized to order.
*@param soda    determines how many sodas is initilized to order.
*@param toGo    determines if order is toGo and is initilized to order.
* 
*@return the order num.
*
*/
//ADDING ORDER
public int addOrder(int ham, int cheese, int veggie, int soda, boolean toGo){
    BurgerOrder order = new BurgerOrder(ham,cheese,veggie,soda,toGo,getNextOrderNum());
    orderList.add(order);
    incrementNextOrderNum();
    return getNextOrderNum()-1;
}
/**
* Method to cancel the last order in ArrayList orderList.
*If the order list size is bigger than 0, orderList is decremented by 1.
*nextOrderNum is also decremented by 1.
*
*@return true if decremented.
*@return false if not decremented.
*/

//CANCEL LAST ORDER// to cancel an order, remove it from list, and decrease ordernumber.
public boolean cancelLastOrder(){
    if(orderList.size()>0){
        orderList.remove(orderList.size()-1); //remove from orderList.
        this.nextOrderNum=nextOrderNum-1; // remove order ID.
        return true;
    }
    else{
        return false;
    }
}
/**
* Method to get numOrderPending.
*
*@return the arrayList orderList size to see if there are any orders pending in ArrayList.
*
*/
//RETURN CURRENT ORDER LIST// return the current number of orders in orderList, not order ID.
public int getNumOrdersPending() {
    return orderList.size();
}
/**
*A method to show if a specific order is done or not.
*
*@param orderID the order being searched for in orderList arrayList.
*@return false  if in arrayList, order is not done.
*@return true   if not in arrayList, order is done.
*/

                              
public boolean isOrderDone(int orderID){ 
     //change boolean to int in method declaration to be able to return 1, 0, -99
    for(int i=0; i<orderList.size(); i++){   //for loop to look at every index of arrayList.
    BurgerOrder order = orderList.get(i);    //create a BurgerOrder object to save the information of object in orderList.
        while(order.getOrderNum() == orderID){ //while the order is still in arrayList.
            return false;                    //return false because order is not ready.
        }
    }
                                            //since we looped the arrayList and no matches were found.
    return true;                            //return true because order is done.
}


/**
*A method to remove a specific order from arrayList and indicate if removed or not.
*
*@param orderID the order being searched for in orderList arrayList.
*@return true   if order is found and removed from arrayList.
*@return false  if order is not found in arrayList.
*/ 


public boolean cancelOrder (int orderID){
    for(int i=0; i < orderList.size(); i++){   //for loop to look at every index of arrayList.
        BurgerOrder order = orderList.get(i);   //create a BurgerOrder object to save information in object of orderList.
        while(order.getOrderNum() == orderID){  //while the order is in arrayList.
            orderList.remove(i);                //remove the order from arrayList.
            return true;                    
        }                                       //since we looped the arrayList and no matches were found.
    }
    return false;                               //return false since order doesn't exist in arrayList.
}


/**
* Method to turn orderList object to string representaion.  
*
*@return string orderList ArrayList.
*
*/
@Override
public String toString(){
    return "FastFoodKitchen{"+"order"+orderList +'}';
}
    }//END OF CLASS