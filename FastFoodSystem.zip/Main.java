import java.util.Scanner; 
public class Main {

    public static void main(String[] args) {

FastFoodKitchen kitchen = new FastFoodKitchen();
Scanner sc = new Scanner(System.in);

while (kitchen.getNumOrdersPending() != -1) { //Changeed 0 to -1 
// numOrdersPending is determined by the size of array. If the size is 0, code should still be able to run

    // see what the user wants to do
    System.out.println("Please select from the following menu of options, by typing a number:");
    System.out.println("\t 1. Order food");
    System.out.println("\t 2. Cancel last order");
    System.out.println("\t 3. Show number of orders currently pending.");
    System.out.println("\t 4. Check order status");
    System.out.println("\t 5. Cancel an order");
    System.out.println("\t 6. Exit");

    int num = sc.nextInt();
    switch (num) {

        case 1:
            System.out.println("How many hamburgers do you want?");
            int ham = sc.nextInt();
            System.out.println("How many cheeseburgers do you want?");
            int cheese = sc.nextInt();
            System.out.println("How many veggieburgers do you want?");
            int veggie = sc.nextInt();
            System.out.println("How many sodas do you want?");
            int sodas = sc.nextInt();
            System.out.println("Is your order to go? (Y/N)");
            char letter = sc.next().charAt(0);
            boolean TOGO = false;
            if (letter == 'Y' || letter == 'y') {
                TOGO = true;
            }
            int orderNum = kitchen.addOrder(ham, cheese, veggie, sodas, TOGO);
            System.out.println("Thank-you. Your order number is " + orderNum+"\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \n");
            
            break;
        case 2:
            boolean ready = kitchen.cancelLastOrder();
            if (ready) {
                System.out.println("Thank you. The last order has been canceled \n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            } else {
                System.out.println("Sorry. There are no orders to cancel.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            }
            
            break;
        case 3:
            System.out.println("There are " + kitchen.getNumOrdersPending() + " pending orders\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            break;
        case 4:
            System.out.println("Enter order number to search.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            int orderStatus = sc.nextInt();  //record order number wanted 
            
            if(kitchen.isOrderDone(orderStatus)== true){ 
                System.out.println("Your order has been completed.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");//if order is complete
            }
            else if(kitchen.isOrderDone(orderStatus) == false){
                System.out.println("Your order is being prepaired.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            }
            else System.out.println("Sorry, we can't find your order number in the system.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            break;

        case 5:
            System.out.println("Enter order number to cancel.\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            int orderCancel = sc.nextInt();  //record order number wanted 
            if (kitchen.cancelOrder(orderCancel) == true){
                System.out.println("Your order has been successfully cancelled\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            }
            else{
                System.out.println("Sorry we can't find your order number in the system\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
            }
            break;

        case 6:
            System.exit(0);
            break;
        default:
            System.out.println("Sorry, but you need to enter a 1, 2, 3, 4, 5, or a 6 \n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");

    }

} // end while loop
/*
        BurgerOrder order1 = new BurgerOrder(3,5,4,10,false,1);
        BurgerOrder order2 = new BurgerOrder(0,0,3,3,true,2);
        BurgerOrder order3 = new BurgerOrder(1,1,0,2,false,3);

        System.out.println(order1);
        System.out.println(order2);
        System.out.println(order3);

Notes: For myself
//when we return ordernumberPending, it should return how many orders in arrayList Kitchen
// so as the order is deleted, should the ID stay the same and size decrease 
//or does ID decrease along with order, so each order get's a new ID?
// I think size should not be realitve to ID
// size decreases bc order is removed, the ID's stay the same even tho they are assigned and deleted at the same time 
//depending on the order in the array 
// size; 6
// 1 2 3 4 5 6
//delete order 4
// size; 5 remain
// 1 2 3 5 6 remain
//so next order number should be 7, not 6. 

Traced from main numOrder = kitchen.add(blah blah blah), to burgerOrder constructor, to .addOrder method in FaFoKit

Problem : your order number in console off by 1, 
it would return the NEW nextOrderNum i(incremented by 1) 

Solution: was fixed by subtracting 1 from return statement, NOT the field


*/
    }
}//end of main method


