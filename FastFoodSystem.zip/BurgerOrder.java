/**
*This is a BurgerOrder class to make burger orders
*@author Luis 
*@version 1.0
*/

//BURGER ORDER CLASS //
public class BurgerOrder{

//FIELDS//
    private int numHamburgers = 0;
    private int numCheeseburgers = 0;
    private int numVeggieburgers = 0;
    private int numSodas = 0;
    private boolean ordersToGo = false;
    private int orderNum = 1;
/**
*Constructs a BurgerOrder object with the input desired by the user.
*@param ham is the amount of hamburgers wanted.
*@param cheese is the amount of cheeseburgers wanted.
*@param veggie is the amount of veggieburgers wanted.
*@param soda is the amount of sodas wanted.
*@param toGo is if the BurgerOrder object is to go or not.
*@param orderNum is the order number of the BurgerOrder object
*/
//CONSTRUCTOR// to make BurgerOrder Objects
public BurgerOrder(int ham, int cheese, int veggie, int soda, boolean toGo, int orderNum){
    this.setNumHamburgers(ham);
    this.setNumCheeseburgers(cheese);
    this.setNumVeggieburgers(veggie);
    this.setNumSodas(soda);
    this.setOrdersToGo(toGo);
    this.setOrderNum(orderNum);
}
//METHODS//

//////////////////////////  GETTERS   //////////////////////////
/**
*Retruns this number of hamburgers
*@return number of hamburgers
*/
public int getNumHamburgers(){ //getter for numHamburger
    return numHamburgers;
}

/**
*Retruns this number of cheeseburgers
*@return number of cheeseburgers
*/
public int getnumCheeseburgers(){ //getter for numCheeseburgers
    return numCheeseburgers;
}
/**
* Returns this number of veggieburgers
*@return number of veggieburgers
*/
public int getnumVeggieburgers(){ //getter for numVeggieburgers
    return numVeggieburgers;
}
/**
*Returns this number of sodas
*@return number of sodas
*/
public int getnumSodas(){ //getter for numSodas
    return numSodas;
}
/**
*Returns true or false depending on if this orders to go
*@return t/f depending on orderToGo
*/
public boolean isOrderToGo(){ //getter for ordersToGo
    return ordersToGo;
}
/**
*Returns this order number
*@return order number
*/
public int getOrderNum(){ //getter for orderNum
    return orderNum;
}

//////////////////////////    SETTERS     //////////////////////////

/**
*Setter to input new value for this numHamburgers.
*If value is less than 0, an error message will print and this numHamburgers will remain 0.
*@param value is the new desired number of this numHamburgers
*/
public void setNumHamburgers(int value){ //setter for setHamburgers
    if(value<0){
        System.out.println("Error");
    }
    else{
        this.numHamburgers = value;
    }
}
/**
*Setter to input new value for this numCheeseburgers.
*If value is less than 0, an error message will print and this numCheeseburgers will remain 0.
*@param value is the new desired number of this numCheeseburgers.
*/
public void  setNumCheeseburgers(int value){ //setter for numCheeseburgers
    if(value<0){
        System.out.println("Error");
    }
    else{
        this.numCheeseburgers = value;
    }
}
/**
*Setter to input new value for this numCheeseburgers.
*If value is less than 0, an error message will print and this numCheeseburgers will remain 0.
*@param value is the new desired number of this numCheeseburgers.
*/
public void  setNumVeggieburgers(int value){ //setter for numVeggieburgers
    if(value<0){
        System.out.println("Error");
    }
    else{
        this.numVeggieburgers = value;
    }
}
/**
*Setter to input new value for this numSodas.
*If value is than 0, an error message will print and this numSodas will remain 0.
*@param value is the new desired number of this numSodas.
*/
public void  setNumSodas(int value){//setter for numSodas
    if(value<0){
        System.out.println("Error");
    }
    else{
        this.numSodas = value;
    }
}
/**
*Setter to change the value of this ordersToGo
*@param value is the new desired true or false for this ordersToGo 
*/
public void  setOrdersToGo(boolean value){//setter for orderToGo
    this.ordersToGo = value;
}
/**
*Setter to change the value of orderNum
*@param value is the new desired true or false for this ordersToGo 
*/
public void  setOrderNum(int value){
    //setter for orderNum
    if(value<0){
        System.out.println("Error");
    }
    else{
        this.orderNum = value;
    }
}


public String toString(){
    return "Burger Order{"+ "numHamburgers="+ numHamburgers + ", cheeseHamburgers="+numCheeseburgers
    +", numVeggieburgers="+ numVeggieburgers+ ", numSodas="+ numSodas+", orderToGo=" +ordersToGo +", orderNum="+orderNum+'}';
}
}//end of BurgerOrder class